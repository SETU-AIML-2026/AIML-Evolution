# Week 3 Lab: what is expected at each exercise, and where to find it

| Exercise | Lecture part, slides | Run | Printout | Answers |
|---|---|---|---|---|
| 1 | Part 1, slides 6 to 11 | `ls.house_dials(2.0, 50)`, `ls.watch_the_loop()`, `ls.keep_going()` | Printout A, Table B, Printout C | 1a Printout A · 1b Table B `loss` · 1c Table B, the dials change at the nudge · 1d you chose the step size · 1e Printout C |
| 2 | Part 2, slides 12 to 19 | `ls.four_shapes()`, `classical.fig_boundaries()` | Table A, the picture | 2a `test` column · 2b `shape` column · 2c the picture · 2d the shape column |
| 3 | Part 3, slides 20 to 23 | `ls.tree_depth_sweep()`, `ls.the_gap()`, `classical.fig_fit()` | Table A, Printout B, the fit picture | 3a `test` column · 3b last row · 3c Printout B · 3d the fit picture |
| 4 | Part 4, slides 24 to 30 | `ls.walk()`, `ls.step_sizes()`, `ls.try_lr(x)`, `ls.bumpy_hill()` | Table A, Table B, your runs, Table C | 4a Table A `step length` · 4b Table B `verdict` · 4c your `try_lr` runs · 4d Table B row 2.05 · 4e Table C last row |
| 5 | Part 5, slides 31 to 37 | `ls.perceptron_vs_xor()`, `ls.hidden_layer()`, `ls.no_bend()` | Table A, Table B, Table C | 5a Table A line 1 · 5b Table B line 1 · 5c Table B last column · 5d Table C |
| 6 | Part 6, slides 38 to 43 | `ls.blame_by_hand()`, `ls.five_lines()` | Printouts A to D, the five lines | 6a Printout A · 6b Printout B · 6c Printout C · 6d the printed comments · 6e red box 6 |

Nothing above points to the booklet, the slides, or any `.py` file. `SUBMISSION.md` is already
filled in; check it against your run, add your name, upload it. Labs are not graded.
