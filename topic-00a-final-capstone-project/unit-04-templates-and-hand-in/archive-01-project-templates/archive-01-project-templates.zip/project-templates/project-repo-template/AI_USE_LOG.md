# AI-use log

One row each time an AI tool helped. Keep it as you go, not at the end.

| Date | Tool | What I asked | What I used | What I changed or checked |
|---|---|---|---|---|
| 2026-10-29 | ChatGPT | Explain Newton's law of cooling in two sentences | The explanation, in my own words | Checked against the student guide: it had the sign right |
