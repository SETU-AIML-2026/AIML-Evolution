# Final project templates

Your project is one detailed report (90%), submitted as one PDF by 23:59 on Wednesday 6 January 2027, plus a ten-minute in-person interview (10%) in the week of 11 January 2027.
Write the report in Word or LaTeX: both templates have the same sections as the outline.

| File | Use it for |
|---|---|
| Project_Report_Outline.pdf | What goes in each section, about how many words, and which marks it earns |
| Project_Report_Template.docx | The report in Word: fill it in, then export as PDF |
| project-report-latex/ | The report in LaTeX: upload the folder to Overleaf (or compile with pdflatex and bibtex) |
| project-repo-template/ | Copy into your GitHub repository: README, AI-use log, folders |

Name your PDF StudentNumber_Surname_Report.pdf and submit it by 23:59 on Wednesday 6 January 2027.
