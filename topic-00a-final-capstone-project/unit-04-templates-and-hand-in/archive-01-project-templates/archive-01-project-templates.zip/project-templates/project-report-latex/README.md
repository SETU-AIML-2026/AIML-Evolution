# LaTeX report template

**Overleaf:** New Project → Upload Project → choose this folder as a zip. Compile with pdfLaTeX.

**On your own computer:** `pdflatex main`, `bibtex main`, `pdflatex main`, `pdflatex main`.

Fill in the commands at the top of `main.tex`, replace each grey `\guide{...}` with your own text,
put your figures in `figures/` with the same names (or change the names in `main.tex`), and add
your sources to `references.bib`. Submit the PDF as StudentNumber_Surname_Report.pdf.
