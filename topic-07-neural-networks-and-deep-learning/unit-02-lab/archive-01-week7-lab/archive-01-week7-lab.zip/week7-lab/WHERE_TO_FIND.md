# Week 7 Lab: which cell to run, and which printout to read, for each question

Predict questions are answered **before** the cell they point at. Build questions need the
`check_my_...` cell to show ✓ on every line. The reference answers are on Tutors, in the
*Week 7 Reference Answers* card: open it after you upload.

| Exercise | Lecture part, slides | Run | Read | Questions |
|---|---|---|---|---|
| 1 | Part 1, 5 to 8 | `ls.three_dials()`, optional `ls.three_dials(b=40)` | Printout A, Printout A2 | 1a predict · 1b, 1c Printout A · 1d Printout A2 · 1e sort |
| 2 | Part 2, 9 to 15 | `ls.umbrella()`, `ls.umbrella(caution=-3)`, `ls.loan()`, `ls.one_line()` | Printouts A, A2, B, Table C and its picture | 2a, 2e predict · 2b Printout A · 2c Printout A2 · 2d Printout B · 2f Table C |
| 3 | Part 3, 16 to 26 | `ls.relu_examples()`, your `my_layer` + `ls.check_my_layer`, `ls.xor_by_hand(my_layer)`, `ls.xor_without_the_bend()`, `ls.count_the_dials()` | Printouts A, B, C, Table D | 3a, 3d predict · 3b build · 3c Printout B · 3e Printout C · 3f Table D |
| 4 | Parts 4 and 5, 27 to 39 | `ls.penalties()`, your `my_nudge` + `ls.check_my_nudge`, `ls.walk_downhill(my_nudge)`, `ls.step_sizes(my_nudge)` | Printout A, Tables B and C | 4a, 4d, 4f predict · 4b Printout A · 4c build · 4e Table B · 4g Table C |
| 5 | Part 6, 40 to 50 | `ls.one_dial()`, `ls.one_dial(truth=9)`, your `my_backward` + `ls.check_my_backward`, `ls.backward_without_the_switch()` | Printouts A, A2, B, C | 5a, 5e predict · 5b Printout A · 5c Printout A2 · 5d build · 5f Printout C |
| 6 | Part 7, 51 to 58 | `ls.train_moons(my_backward)`, `ls.train_credit(my_backward)`, optional `ls.train_credit(my_backward, step=2.0)` | Table A and its picture, Tables B and B2 | 6a, 6d predict · 6b, 6c Table A · 6e, 6f Table B · 6g Table B2 |

Nothing above needs the booklet or the slides, and you never need to open a `.py` file.
Labs are not graded.
