# Week 7 Lab: Submission

**Name:**   **Student number:**

> **This sheet is blank on purpose.** Fill it in as you go through the notebook. Each question is
> one of five kinds:
>
> - **Predict**: write it *before* you run the cell. A wrong prediction is fine; it is the most
>   useful line on the sheet, because it shows you exactly what to rethink. Do not change it
>   afterwards. Say whether you were right in the next question instead.
> - **Record**: the number from the printout the question names.
> - **Explain**: two or three sentences in your own words. No need to quote the slides.
> - **Build**: paste the line (or lines) of code that passed its check.
> - **Change**: predict, change one thing, run, and say what happened.
>
> Upload this file when you are done, **then** open *Week 7 Reference Answers* on Tutors and
> compare. Labs are not graded: what you write here is for you, and it shows us where the
> material needs work.

---

## Exercise 1 · A formula with dials  *(lecture Part 1, slides 5 to 8)*

**1a · Predict.** With the base price at €60k, which of a = 1000, 2000 or 3000 gives the smallest
loss? Is the loss for the other two closer to 90, 900 or 9,000?

>

**1b · Record.** Loss for a = 1000: ______   a = 2000: ______   a = 3000: ______   Was 1a right?

>

**1c · Explain.** Why are the losses for a = 1000 and a = 3000 exactly the same?

>

**1d · Change** *(optional)*. Prediction for a base price of €40k: is a = 2000 still best?
Then from Printout A2: the loss at a = 2000 ______ and the best a ______. What does this tell you
about the two dials?

>

**1e · Explain.** Parameters (the computer learns them):
Hyperparameters (you choose them):

---

## Exercise 2 · One neuron  *(lecture Part 2, slides 9 to 15)*

**2a · Predict.** Your hand-worked umbrella score, and whether "how sure" is below 50%, about 70%,
or above 90%.

>

**2b · Record.** Score: ______   How sure: ______   Was 2a right?

>

**2c · Change.** Prediction with a caution of −3, then the result from Printout A2.

>

**2d · Explain.** Which loan clue argues against default, and how can you tell from the numbers alone?

>

**2e · Predict.** One neuron on the two moons: about 60%, about 85% or about 99% of new dots right?

>

**2f · Record and explain.** Right on new dots: ______. Where are the mistakes, and why can no
setting of the weights fix them?

>

---

## Exercise 3 · How it is wired  *(lecture Part 3, slides 16 to 26)*

**3a · Predict.** ReLU(−3) = ______   ReLU(0.5) = ______   ReLU(2) = ______

**3b · Build.** Your line in `my_layer`:

```python

```

**3c · Record and explain.** The four answers from Printout B: ______. Which two dots share a hidden
pair, and why does that let one straight line work?

>

**3d · Predict.** With no bend, which dot (if any) will get the wrong answer?

>

**3e · Explain.** Was 3d right? In one sentence: why does every neuron need a bend?

>

**3f · Record and explain.** Total dials from Table D: ______. Where does each layer's number come from?

>

---

## Exercise 4 · Check and nudge  *(lecture Parts 4 and 5, slides 27 to 39)*

**4a · Predict.** Rank the penalties for 90% sure, 50/50 and 5% sure. Is the biggest about 2 times
or about 30 times the smallest?

>

**4b · Record.** Penalties: 90% ______   50% ______   5% ______   Was 4a right?

**4c · Build.** Your line in `my_nudge`:

```python

```

**4d · Predict.** After five steps from a = 1000 with step size 40: about 1300, about 1700, or very
close to 2000?

>

**4e · Record and explain.** a after five steps (Table B): ______. Why does a negative slope make the
dial go up?

>

**4f · Predict.** For step sizes 5, 40, 100, 120 and 130: crawl, settle, bounce or explode?

>

**4g · Record and explain.** Table C: where a ends for each step size. Between which two step sizes
does the valley switch from settling to exploding?

>

---

## Exercise 5 · Blame  *(lecture Part 6, slides 40 to 50)*

**5a · Predict.** One dial (w = 3, x = 2, b = 1, truth = 5): positive or negative blame, and nearer
2, 8 or 20?

>

**5b · Record and explain.** Blame by nudging ______   by the chain rule ______. Why is the nudging
one slightly bigger?

>

**5c · Change.** Prediction for truth = 9, then the result from Printout A2: the blame, and which way
w should turn.

>

**5d · Build.** Your three lines in `my_backward`:

```python
delta =                    # rule 1
gW[i] =                    # rule 2
delta =                    # rule 3
```

**5e · Predict.** If rule 3 forgot the switched-off neurons, would the check pass? Difference about
1e-6, about 1e-3, or about 0.5?

>

**5f · Record and explain.** Difference in Printout C: ______. What does it tell you about how a
gradient check catches mistakes?

>

---

## Exercise 6 · The loop, running  *(lecture Part 7, slides 51 to 58)*

**6a · Predict.** After 200 epochs on the moons, what share of new dots right? Will it beat
Exercise 2's straight line?

>

**6b · Record.** Table A, right on new dots at epochs 0, 10, 50, 100, 200:
______ ______ ______ ______ ______   Was 6a right?

**6c · Explain.** What would you have concluded if you had stopped at epoch 50?

>

**6d · Predict.** On the credit data, will the network beat logistic regression by a lot (5 points or
more) or a little (under 1 point)?

>

**6e · Record.** From Table B: everyone "no default" ______   logistic regression ______
network at epoch 20 ______   defaulters caught ______

**6f · Explain.** Why does a curved boundary help so much on the moons and so little here? What would
you change, from Week 2, to catch more defaulters?

>

**6g · Change** *(optional)*. Prediction for step size 2.0, then from Table B2: accuracy ______ and
test loss ______ at epoch 20. Why should you never judge a run on accuracy alone?

>

---

## Two last questions

**L1.** The four steps of the loop, in order, and the line of *your* code that does each one.

>

**L2.** Which prediction today was furthest off, and what do you think now?

>
