"""lecture_steps.py — one helper per lecture idea, and the checks for the code you write.

You run these from the notebook; you never need to edit or open this file.
"""
import os
import warnings

import numpy as np
import matplotlib.pyplot as plt

import nets

warnings.filterwarnings("ignore")
os.makedirs("figures", exist_ok=True)


def _ok(msg):
    print(f"  ✓ {msg}")


def _no(msg):
    print(f"  ✗ {msg}")


def _boundary(predict, X, y, title, fname):
    gx, gy = np.meshgrid(np.linspace(-1.6, 2.6, 300), np.linspace(-1.15, 1.6, 220))
    P = np.asarray(predict(np.c_[gx.ravel(), gy.ravel()])).reshape(gx.shape)
    plt.figure(figsize=(6, 3.8))
    plt.contourf(gx, gy, P, levels=np.linspace(0, 1, 21), cmap="RdBu_r", alpha=0.35)
    plt.contour(gx, gy, P, levels=[0.5], colors="k")
    plt.scatter(X[:, 0], X[:, 1], c=y.ravel(), cmap="coolwarm", s=10)
    plt.title(title)
    plt.xticks([]); plt.yticks([])
    plt.tight_layout()
    plt.savefig(os.path.join("figures", fname), dpi=110)
    plt.show()


# ============================================================ Exercise 1 · a formula with dials
def three_dials(b=60):
    """Part 1. price = a × size + base price, for three settings of dial a."""
    print(f"Printout A{'' if b == 60 else '2'}: three houses, base price b = {b} (thousand euro)")
    print("  sizes 60, 90, 120 m²   real prices 180, 240, 300 (thousand euro)\n")
    print(f"  {'dial a':>7}   {'guesses':<26} {'misses':<26} {'loss':>6}")
    for a in (1000, 2000, 3000):
        g = a * nets.SIZES / 1000 + b
        m = g - nets.PRICES
        print(f"  {a:>7}   {str(g.round(0).astype(int).tolist()):<26} {str(m.round(0).astype(int).tolist()):<26} {np.mean(m**2):>6.0f}")
    aa = np.arange(0, 4001, 1.0)
    losses = [np.mean((a * nets.SIZES / 1000 + b - nets.PRICES) ** 2) for a in aa]
    best = aa[int(np.argmin(losses))]
    print(f"\n  trying every a from 0 to 4000: the lowest loss is {min(losses):.0f}, at a = {best:.0f}")


# ============================================================ Exercise 2 · one neuron
def umbrella(caution=-1.0):
    """Part 2. score = trust × clue, added up, plus caution; how sure = squash(score)."""
    clues = [("dark clouds", 1.0, 0.5), ("forecast", 0.8, 2.0), ("wind", 0.2, -1.0)]
    print(f"Printout A{'' if caution == -1.0 else '2'}: the umbrella neuron, caution = {caution}")
    total = 0.0
    for name, x, w in clues:
        print(f"  {name:<12} clue {x:>4}  × trust {w:>5}  =  vote {x * w:>5.2f}")
        total += x * w
    z = total + caution
    p = nets.sigmoid(z)
    print(f"  votes add up to {total:.2f};  + caution {caution}  →  score z = {z:.2f}")
    print(f"  squash(z) = {p:.2f}  →  {p:.0%} sure  →  {'take the umbrella' if p > 0.5 else 'leave it at home'}")


def loan():
    """Part 2. The same neuron, on the Week 1 credit data."""
    clues = [("missed payments", 2.0, 0.8), ("debt ÷ income", 0.5, 1.2), ("years in same job", 6.0, -0.3)]
    print("Printout B: the loan neuron, caution = −1")
    total = 0.0
    for name, x, w in clues:
        print(f"  {name:<18} clue {x:>4}  × trust {w:>5}  =  vote {x * w:>5.2f}")
        total += x * w
    z = total - 1.0
    print(f"  votes add up to {total:.2f};  + caution −1  →  score z = {z:.2f}")
    print(f"  squash(z) = {nets.sigmoid(z):.2f}  →  {nets.sigmoid(z):.0%} likely to miss payments")


def one_line():
    """Part 2. One neuron (logistic regression) on the two moons."""
    from sklearn.linear_model import LogisticRegression
    Xtr, ytr, Xte, yte = nets.load_moons()
    m = LogisticRegression().fit(Xtr, ytr.ravel())
    print("Table C: one neuron on the two moons")
    print(f"  right on the 420 practice dots: {m.score(Xtr, ytr.ravel()):.3f}")
    print(f"  right on the 180 new dots:      {m.score(Xte, yte.ravel()):.3f}")
    _boundary(lambda P: m.predict_proba(P)[:, 1], Xtr, ytr, "one neuron: one straight line", "01_one_line.png")


# ============================================================ Exercise 3 · how it is wired
def relu_examples():
    """Part 3. ReLU(z) = max(0, z)."""
    print("Printout A: ReLU(z) = max(0, z)")
    for zz in (-3, -1, 0, 0.5, 2):
        print(f"  ReLU({zz:>4}) = {max(0, zz):g}")


def check_my_layer(my_layer):
    """Exercise 3, Build. Is my_layer(X, W, b) the same as ReLU(X @ W + b)?"""
    print("Check: my_layer")
    rng = np.random.default_rng(7)
    X, W, b = rng.normal(size=(5, 3)), rng.normal(size=(3, 4)), rng.normal(size=(1, 4))
    try:
        out = my_layer(X, W, b)
    except Exception as e:
        _no(f"calling it raised {type(e).__name__}: {e}")
        return
    if out is None:
        _no("it returns None. Replace `return None` with your one line.")
        return
    out = np.asarray(out, dtype=float)
    if out.shape != (5, 4):
        _no(f"5 dots into a layer of 4 neurons should give a 5 × 4 table; yours is {out.shape}. Check the order in X @ W.")
        return
    _ok("5 dots into 4 neurons gives a 5 × 4 table")
    if (out < -1e-12).any():
        _no("some outputs are negative. The bend should turn every negative score into 0.")
        return
    _ok("no negative outputs: the bend is there")
    if not np.allclose(out, np.maximum(0, X @ W + b)):
        _no("the numbers are not ReLU(X @ W + b). Did you add the bias b before bending?")
        return
    _ok("every number matches ReLU(X @ W + b). Well done.")


def xor_by_hand(my_layer):
    """Part 3. Two hidden neurons wired by hand: h1 = ReLU(x1 + x2), h2 = ReLU(x1 + x2 − 1), answer = h1 − 2 h2."""
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], float)
    W1, b1, W2 = np.array([[1, 1], [1, 1]], float), np.array([[0, -1]], float), np.array([[1], [-2]], float)
    H = np.asarray(my_layer(X, W1, b1), float)
    out = H @ W2
    print("Printout B: XOR, with your layer")
    for x, h, o in zip(X.astype(int).tolist(), H, out):
        print(f"  dot {tuple(x)}  →  hidden (h1, h2) = ({h[0]:g}, {h[1]:g})  →  answer {o[0]:g}")


def xor_without_the_bend():
    """Part 3. The same wiring with the bend taken out."""
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], float)
    W1, b1, W2 = np.array([[1, 1], [1, 1]], float), np.array([[0, -1]], float), np.array([[1], [-2]], float)
    H = X @ W1 + b1
    out = H @ W2
    want = [0, 1, 1, 0]
    print("Printout C: the same wiring, no bend")
    for x, h, o, w in zip(X.astype(int).tolist(), H, out, want):
        flag = "" if o[0] == w else "   ← wrong: should be " + str(w)
        print(f"  dot {tuple(x)}  →  hidden ({h[0]:g}, {h[1]:g})  →  answer {o[0]:g}{flag}")


def count_the_dials():
    """Part 3. Today's network, 2 → 16 → 16 → 1."""
    W, b = nets.init([2, 16, 16, 1])
    print("Table D: the dials in a 2 → 16 → 16 → 1 network")
    total = 0
    for i, (Wi, bi) in enumerate(zip(W, b), 1):
        print(f"  layer {i}: weight table {Wi.shape[0]} × {Wi.shape[1]} = {Wi.size:>3} weights, plus {bi.size:>2} biases = {Wi.size + bi.size:>3}")
        total += Wi.size + bi.size
    print(f"  total: {total} dials")


# ============================================================ Exercise 4 · check and nudge
def penalties():
    """Part 4. Cross-entropy: − log(how sure it was of the right answer)."""
    print("Printout A: the penalty for one dot whose right answer is orange")
    for p in (0.9, 0.5, 0.05):
        print(f"  {p:4.0%} sure of the right answer  →  penalty − log({p}) = {-np.log(p):.2f}")


def check_my_nudge(my_nudge):
    """Exercise 4, Build. Is my_nudge(dial, slope, step) = dial − step × slope?"""
    print("Check: my_nudge")
    cases = [((1000, -17.4, 40), 1696.0, "the lecture's first step"), ((10, 2, 0.5), 9.0, "a positive slope"),
             ((5, 0, 3), 5.0, "a flat slope")]
    for (d, s, st), want, what in cases:
        try:
            got = my_nudge(d, s, st)
        except Exception as e:
            _no(f"calling it raised {type(e).__name__}: {e}")
            return
        if got is None:
            _no("it returns None. Replace `return None` with your one line.")
            return
        if abs(float(got) - want) > 1e-9:
            hint = " Is the sign right? Downhill means against the slope." if abs(float(got) - (d + st * s)) < 1e-9 else ""
            _no(f"{what}: dial {d}, slope {s}, step {st} should give {want:g}, yours gives {float(got):g}.{hint}")
            return
        _ok(f"{what}: {d} − {st} × ({s}) = {want:g}")
    print("  All correct.")


def _house_slope(a, b=60):
    m = a * nets.SIZES / 1000 + b - nets.PRICES
    return float(np.mean(m ** 2)), float(np.mean(2 * m * nets.SIZES / 1000))


def walk_downhill(my_nudge, step=40):
    """Part 5. The house dial walks downhill using your nudge."""
    print(f"Table B: the house dial, starting at a = 1000, step size {step}")
    a = 1000.0
    for k in range(6):
        L, s = _house_slope(a)
        print(f"  step {k}:  a = {a:7.1f}   slope = {s:6.2f}   loss = {L:7.1f}")
        a = float(my_nudge(a, s, step))


def step_sizes(my_nudge):
    """Part 5. Twenty steps, for five step sizes."""
    print("Table C: where dial a ends after 20 steps (the valley floor is at 2000)")
    for step in (5, 40, 100, 120, 130):
        a = 1000.0
        for _ in range(20):
            a = float(my_nudge(a, _house_slope(a)[1], step))
        print(f"  step size {step:>3}:  a = {a:12.1f}")


# ============================================================ Exercise 5 · blame
def one_dial(truth=5):
    """Part 6. One dial: blame by nudging, and by the chain rule."""
    x, b, w = 2.0, 1.0, 3.0

    def loss(w):
        return (w * x + b - truth) ** 2
    nudge = 0.001
    by_nudging = (loss(w + nudge) - loss(w)) / nudge
    miss = w * x + b - truth
    print(f"Printout A{'' if truth == 5 else '2'}: one dial  w = 3, x = 2, b = 1, truth = {truth}")
    print(f"  forward: guess = 3 × 2 + 1 = 7,  miss = {miss:g},  loss = {loss(w):g}")
    print(f"  nudge w to 3.001: guess 7.002, loss {loss(w + nudge):.6f}")
    print(f"  blame by nudging        = ({loss(w + nudge):.6f} − {loss(w):g}) ÷ 0.001 = {by_nudging:.3f}")
    print(f"  blame by the chain rule = (2 × miss) × x = {2 * miss:g} × 2 = {2 * miss * x:.3f}")
    print(f"  so turn w {'down' if 2 * miss * x > 0 else 'up'}")


def _gradcheck(backward_fn):
    Xtr, ytr, _, _ = nets.load_moons()
    X, y = Xtr[:64], ytr[:64]
    W, b = nets.init([2, 16, 16, 1])
    h, z = nets.forward(X, W, b)
    gW, gb = backward_fn(h, z, W, y)
    mine = np.concatenate([np.asarray(g, float).ravel() for g in list(gW) + list(gb)])
    nudged = []
    for P in W + b:
        for idx in np.ndindex(P.shape):
            old = P[idx]
            P[idx] = old + 1e-5; up = nets.bce(nets.forward(X, W, b)[0][-1], y)
            P[idx] = old - 1e-5; dn = nets.bce(nets.forward(X, W, b)[0][-1], y)
            P[idx] = old
            nudged.append((up - dn) / 2e-5)
    nudged = np.array(nudged)
    return len(nudged), np.linalg.norm(mine - nudged) / (np.linalg.norm(mine) + np.linalg.norm(nudged))


def check_my_backward(my_backward):
    """Exercise 5, Build. Does my_backward agree with nudging, for all 337 dials?"""
    print("Check: my_backward")
    Xtr, ytr, _, _ = nets.load_moons()
    W, b = nets.init([2, 16, 16, 1])
    h, z = nets.forward(Xtr[:8], W, b)
    try:
        gW, gb = my_backward(h, z, W, ytr[:8])
    except Exception as e:
        if "NoneType" in str(e):
            _no("a line still says None. Fill in rules 1, 2 and 3, starting with rule 1.")
        else:
            _no(f"calling it raised {type(e).__name__}: {e}")
        return
    if any(g is None for g in list(gW) + list(gb)):
        _no("some blames are None. Fill in rules 1, 2 and 3.")
        return
    shapes_ok = all(np.shape(g) == Wi.shape for g, Wi in zip(gW, W))
    if not shapes_ok:
        _no(f"each weight's blame should have the same shape as the weight table: {[Wi.shape for Wi in W]}; "
            f"yours are {[np.shape(g) for g in gW]}. Rule 2 is  h[i].T @ delta.")
        return
    _ok("every blame table has the same shape as its weight table")
    n, rel = _gradcheck(my_backward)
    print(f"  Printout B: {n} dials checked against nudging   relative difference {rel:.1e}")
    if rel < 1e-6:
        _ok("your backpropagation agrees with nudging. Well done.")
    elif rel < 0.1:
        _no("close, but not right. Check that rule 1 divides by the number of dots, len(y).")
    else:
        _no("far off. Check rule 3: hand the blame back through W[i].T, and zero it where z[i-1] <= 0.")


def backward_without_the_switch():
    """Part 6. The same check, with the 'switched-off neurons pass no blame' part removed."""
    def broken(h, z, W, y):
        gW, gb = [None] * len(W), [None] * len(W)
        delta = (h[-1] - y) / len(y)
        for i in reversed(range(len(W))):
            gW[i] = h[i].T @ delta
            gb[i] = delta.sum(0, keepdims=True)
            if i > 0:
                delta = delta @ W[i].T
        return gW, gb
    n, rel = _gradcheck(broken)
    print(f"Printout C: backpropagation without the switch   {n} dials checked   relative difference {rel:.1e}")


# ============================================================ Exercise 6 · the loop
def train_moons(my_backward):
    """Part 7. Guess, check, blame (your backward), nudge, on the two moons."""
    Xtr, ytr, Xte, yte = nets.load_moons()
    W, b, rows = nets.train(Xtr, ytr, [2, 16, 16, 1], my_backward, step=0.05, batch=32, epochs=200,
                            report=(0, 10, 50, 100, 200), Xte=Xte, yte=yte)
    print("Table A: training the 2 → 16 → 16 → 1 network with your backward")
    for r in rows:
        print(f"  epoch {r['epoch']:>3}   loss {r['loss']:.3f}   right on new dots {r['right']:.0%}")
    _boundary(lambda P: nets.forward(P, W, b)[0][-1], Xtr, ytr, "after 200 epochs", "02_moons.png")


def train_credit(my_backward, step=0.05):
    """Part 7. The same kind of network on the Week 1 credit data, against Week 2's straight line."""
    from sklearn.linear_model import LogisticRegression
    Xtr, ytr, Xte, yte = nets.load_credit()
    print(f"Table B{'' if step == 0.05 else '2'}: the credit data (22,500 to learn from, 7,500 to test)")
    print(f"  say 'no default' to everyone:      accuracy {1 - yte.mean():.3f}")
    lr_model = LogisticRegression(max_iter=1000).fit(Xtr, ytr.ravel())
    print(f"  logistic regression (Week 2):      accuracy {lr_model.score(Xte, yte.ravel()):.3f}")
    W, b, rows = nets.train(Xtr, ytr, [23, 16, 16, 1], my_backward, step=step, batch=64, epochs=20,
                            report=(1, 5, 10, 20), Xte=Xte, yte=yte)
    for r in rows:
        print(f"  network, epoch {r['epoch']:>2}:              accuracy {r['right']:.3f}   test loss {r['test_loss']:.3f}")
    p = nets.forward(Xte, W, b)[0][-1] > 0.5
    recall = (p & (yte == 1)).sum() / (yte == 1).sum()
    print(f"  network: {sum(Wi.size for Wi in W) + sum(bi.size for bi in b)} dials, step size {step}, "
          f"catches {recall:.1%} of the people who really defaulted")


# ============================================================ Going further
def memorising(decay=0.0):
    """80 noisy dots and a big network: does it memorise? Try decay=0.01."""
    from sklearn.datasets import make_moons
    Xs, ys = make_moons(80, noise=0.35, random_state=3); ys = ys.reshape(-1, 1).astype(float)
    Xv, yv = make_moons(400, noise=0.35, random_state=4); yv = yv.reshape(-1, 1).astype(float)
    W, b, _ = nets.train(Xs, ys, [2, 64, 64, 1], nets.backward, step=0.1, batch=16, epochs=1500, decay=decay, seed=2)
    tr = float(((nets.forward(Xs, W, b)[0][-1] > 0.5) == ys).mean())
    te = float(((nets.forward(Xv, W, b)[0][-1] > 0.5) == yv).mean())
    print(f"Weight decay {decay}:  right on practice dots {tr:.3f}   right on new dots {te:.3f}   gap {tr - te:.3f}")


def thresholds(my_backward):
    """Recall and precision on defaulters at three cut-offs."""
    Xtr, ytr, Xte, yte = nets.load_credit()
    W, b, _ = nets.train(Xtr, ytr, [23, 16, 16, 1], my_backward, step=0.05, batch=64, epochs=20)
    p = nets.forward(Xte, W, b)[0][-1]
    for t in (0.5, 0.3, 0.2):
        pred = p > t
        tp = (pred & (yte == 1)).sum()
        print(f"  cut-off {t}:  catches {tp / (yte == 1).sum():.1%} of defaulters;  {tp / pred.sum():.1%} of flags are right")


def broken_run(fix_sign=False, fix_scaling=False, fix_step=False):
    """A training run with three problems. Fix one at a time and watch what changes."""
    Xtr, ytr, Xte, yte = nets.load_credit(scale=fix_scaling)
    with np.errstate(all="ignore"):
        W, b, rows = nets.train(Xtr, ytr, [23, 16, 16, 1], nets.backward, step=0.05 if fix_step else 5.0,
                                batch=64, epochs=10, report=(10,), Xte=Xte, yte=yte, sign=-1.0 if fix_sign else 1.0)
    r = rows[-1]
    print(f"  sign fixed: {fix_sign!s:5}  scaling fixed: {fix_scaling!s:5}  step fixed: {fix_step!s:5}  →  "
          f"test loss {r['test_loss']:.3f}   accuracy {r['right']:.3f}")


def five_lines():
    """The same loop in PyTorch, if it is installed; otherwise the five lines are printed."""
    lines = ["for epoch in range(epochs):",
             "    optimiser.zero_grad()        # 0. wipe last time's blame",
             "    pred = model(X)              # 1. GUESS",
             "    loss = loss_fn(pred, Y)      # 2. CHECK",
             "    loss.backward()              # 3. BLAME",
             "    optimiser.step()             # 4. NUDGE"]
    try:
        import torch  # noqa: F401
    except ImportError:
        print("PyTorch is not installed (not needed). The five lines are:\n")
        print("\n".join(lines))
        return
    import torch
    Xtr, ytr, Xte, yte = nets.load_moons()
    X, Y = torch.tensor(Xtr, dtype=torch.float32), torch.tensor(ytr, dtype=torch.float32)
    torch.manual_seed(0)
    model = torch.nn.Sequential(torch.nn.Linear(2, 16), torch.nn.ReLU(), torch.nn.Linear(16, 16), torch.nn.ReLU(),
                                torch.nn.Linear(16, 1), torch.nn.Sigmoid())
    optimiser, loss_fn = torch.optim.Adam(model.parameters(), lr=0.01), torch.nn.BCELoss()
    print("\n".join(lines))
    for epoch in range(300):
        optimiser.zero_grad(); pred = model(X); loss = loss_fn(pred, Y); loss.backward(); optimiser.step()
    acc = ((model(torch.tensor(Xte, dtype=torch.float32)).detach().numpy() > 0.5) == yte).mean()
    print(f"\nPyTorch, 300 epochs: right on new dots {acc:.0%}")
