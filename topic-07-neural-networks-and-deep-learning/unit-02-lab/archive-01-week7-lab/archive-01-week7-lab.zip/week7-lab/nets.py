"""nets.py — the code behind the Week 7 lab: the data, and a small network in plain NumPy.

You never need to open this file. lecture_steps.py calls it.
"""
import numpy as np
import pandas as pd
from sklearn.datasets import make_moons
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# ---------------------------------------------------------------- data
SIZES = np.array([60.0, 90.0, 120.0])      # the three houses, m²
PRICES = np.array([180.0, 240.0, 300.0])   # their prices, thousands of euro


def load_moons():
    """The lecture's two moons: 420 dots to learn from, 180 kept back."""
    X, y = make_moons(600, noise=0.2, random_state=0)
    y = y.reshape(-1, 1).astype(float)
    p = np.random.default_rng(0).permutation(600)
    return X[p[:420]], y[p[:420]], X[p[420:]], y[p[420:]]


def load_credit(path="UCI_Credit_Card.csv", scale=True):
    """The UCI credit data, split exactly as in Week 2 (25% test, random_state=0, stratified)."""
    df = pd.read_csv(path)
    y = df["default.payment.next.month"].to_numpy().reshape(-1, 1).astype(float)
    X = df.drop(columns=["ID", "default.payment.next.month"]).to_numpy(float)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=0, stratify=y)
    if scale:
        sc = StandardScaler().fit(Xtr)
        Xtr, Xte = sc.transform(Xtr), sc.transform(Xte)
    return Xtr, ytr, Xte, yte


# ---------------------------------------------------------------- the network
def relu(z):
    return np.maximum(0, z)


def sigmoid(z):
    return 1 / (1 + np.exp(-np.clip(z, -60, 60)))


def bce(p, y):
    p = np.clip(p, 1e-12, 1 - 1e-12)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


def init(sizes, seed=1):
    """Random weight tables (scaled to each layer's size) and zero biases."""
    rng = np.random.default_rng(seed)
    W = [rng.normal(0, np.sqrt(2 / m), (m, n)) for m, n in zip(sizes[:-1], sizes[1:])]
    b = [np.zeros((1, n)) for n in sizes[1:]]
    return W, b


def forward(X, W, b):
    """GUESS. Returns h (every layer's numbers, h[0] = X, h[-1] = guesses) and z (every layer's scores)."""
    h, z = [X], []
    for i, (Wi, bi) in enumerate(zip(W, b)):
        zi = h[-1] @ Wi + bi
        z.append(zi)
        h.append(sigmoid(zi) if i == len(W) - 1 else relu(zi))
    return h, z


def backward(h, z, W, y):
    """BLAME. The three rules of backpropagation (the reference version)."""
    gW, gb = [None] * len(W), [None] * len(W)
    delta = (h[-1] - y) / len(y)
    for i in reversed(range(len(W))):
        gW[i] = h[i].T @ delta
        gb[i] = delta.sum(0, keepdims=True)
        if i > 0:
            delta = (delta @ W[i].T) * (z[i - 1] > 0)
    return gW, gb


def train(Xtr, ytr, sizes, backward_fn, step=0.05, batch=32, epochs=200, report=(), Xte=None, yte=None,
          decay=0.0, seed=1, sign=-1.0):
    """GUESS, CHECK, BLAME, NUDGE, batch after batch. Returns the dials and a list of report rows."""
    W, b = init(sizes, seed)
    rng = np.random.default_rng(0)
    rows = []

    def row(epoch):
        p_tr = forward(Xtr, W, b)[0][-1]
        r = {"epoch": epoch, "loss": bce(p_tr, ytr)}
        if Xte is not None:
            p = forward(Xte, W, b)[0][-1]
            r.update(test_loss=bce(p, yte), right=float(((p > 0.5) == yte).mean()))
        rows.append(r)

    if 0 in report:
        row(0)
    for epoch in range(1, epochs + 1):
        order = rng.permutation(len(Xtr))
        for s in range(0, len(Xtr), batch):
            idx = order[s:s + batch]
            h, z = forward(Xtr[idx], W, b)                 # 1 GUESS
            gW, gb = backward_fn(h, z, W, ytr[idx])        # 2 CHECK and 3 BLAME
            gW = [g + decay * Wi for g, Wi in zip(gW, W)]
            for P, g in zip(W + b, gW + gb):
                P += sign * step * g                       # 4 NUDGE
        if epoch in report:
            row(epoch)
    return W, b, rows
