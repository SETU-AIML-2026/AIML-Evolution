# Week 7 Lab: How a Machine Learns, and How It Is Wired

**AI Principles and Practice · SETU**

> **You do not need the booklet for this lab.** Every question says which printout to read.

The lecture had seven parts. The lab has **six exercises, in the same order** (Exercise 4 covers
Parts 4 and 5). In each one you **predict** before you run, **run** the experiment, **look** at the
printout the question names, and **explain** the result in your own words. In Exercises 3, 4 and 5
you also **build** three pieces of a neural network yourself: a layer, the nudge, and
backpropagation. By the end of Exercise 5 the network that learns the two moons runs on your own code.

| Exercise | Lecture part | Slides | You build | Time |
|---|---|---|---|---|
| 1 · A formula with dials | Part 1 | 5 to 8 | | 15 min |
| 2 · One neuron | Part 2 | 9 to 15 | | 20 min |
| 3 · How it is wired | Part 3 | 16 to 26 | a layer | 25 min |
| 4 · Check and nudge | Parts 4 and 5 | 27 to 39 | the nudge | 20 min |
| 5 · Blame | Part 6 | 40 to 50 | backpropagation | 25 min |
| 6 · The loop, running | Part 7 | 51 to 58 | | 20 min |
| | Two last questions, then upload `SUBMISSION.md` | | | 10 min |

About 2 h 15 min. **If any exercise takes more than 40 minutes, stop and post in the channel.**
That is a bug in the material, not in you.

## What you need

Python 3.10 or newer with the packages in `requirements.txt`. **No PyTorch and no deep-learning
library.** Or Google Colab: upload the folder, open the notebook.

```bash
pip install -r requirements.txt      # numpy, pandas, scikit-learn, matplotlib, notebook
jupyter notebook week7_lab.ipynb
```

## The files (you only open three)

| file | what it is | do I need it? |
|---|---|---|
| `week7_lab.ipynb` | **The lab.** Open this. | **yes** |
| `SUBMISSION.md` | **The answer sheet, blank.** Fill it in as you go, add your name, upload it. | **yes** |
| `WHERE_TO_FIND.md` | One table: for each question, which cell to run and which printout to read. | **yes** |
| `lecture_steps.py` | One helper per lecture idea, and the checks for the code you write. You never edit it. | no |
| `nets.py` | The data and the network behind the exercises. | no |
| `UCI_Credit_Card.csv` | The Week 1 credit data, for Exercise 6. | no |

Dataset for Exercise 6: Yeh, I. and Lien, C. (2009), *UCI Machine Learning Repository*,
https://doi.org/10.24432/C55S3H, licensed CC BY 4.0.
