# Week 4 Lab: what is expected at each exercise, and where to find it

| Exercise | Lecture part, slides | Run | Printouts | Answers |
|---|---|---|---|---|
| 1 | Part 1, 7 to 13 | `ls.guess_the_rule()`, `ls.the_race()`, `ls.shuffle_test()` | Printout A, Table B, Table C | 1a Printout A · 1b, 1c Table B · 1d, 1e Table C |
| 2 | Part 2, 14 to 20 | `ls.by_hand()`, `ls.kernel_walk()`, `ls.equivariance()` | Printouts A to D, Table B, Table C | 2a Printouts B, C, D · 2b Printout A · 2c Table B · 2d, 2e Table C |
| 3 | Part 3, 21 to 25 | `ls.depth_reaches()`, `ls.the_head()`, `ls.no_payoff()` | Table A, Table B, Table C | 3a Table A · 3b, 3c Table B · 3d Table C |
| 4 | Part 4, 26 to 35 | `ls.a_power()`, `ls.gradient_through_time()`, `ls.half_life()`, `ls.memory_task()` | Printout A, Tables B, C, D | 4a Printout A · 4b Table B · 4c Table C · 4d, 4e Table D |
| 5 | Part 5, 36 to 45 | `ls.soft_lookup()`, `ls.four_instructions()`, `ls.cannot_see_order()`, `ls.the_bill()` | Table A, Printout B, Table C, Table D | 5a, 5b Table A · 5c Printout B · 5d Table C · 5e Table D |
| 6 | Part 6, 46 to 50 | `ls.the_bargain()`, `ls.seven_questions()` | Table A, Printout B | 6a, 6b, 6c Table A · 6d, 6e Printout B |

Nothing above points to the booklet, the slides, or any `.py` file. `SUBMISSION.md` is already
filled in; check it against your run, add your name, upload it. Labs are not graded.
