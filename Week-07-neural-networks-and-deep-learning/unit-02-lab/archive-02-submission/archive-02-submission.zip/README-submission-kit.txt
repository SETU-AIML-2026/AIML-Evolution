Week 7 lab submission kit — AI Principles and Practice
======================================================

Unzip this into the same folder as your Week 7 lab work, so that it sits
alongside UCI_Credit_Card.csv and w7lab.py from the Week 07 Lab Files archive.

  SUBMISSION.md        Your answers. Fill it in and delete each TODO.
  make_submission.py   Builds the single zip you upload. Run it last.
  setup_check.py       Environment report. Run it before the lab.
                       PyTorch is listed as optional: you only need it
                       for Exercise 7.5.

Three steps, the same every week:

  1. Answer SUBMISSION.md as you work through Sections 1 to 7
  2. python make_submission.py
  3. Upload the one zip it names to the OneDrive folder on the course site

Keep your code and pictures in this folder as you write them (mlp.py,
section1_dials.py ... section6_credit.py, exercise_7_*.py, your fixed
broken_run.py, the .png files). They go into the zip automatically.
The provided UCI_Credit_Card.csv and w7lab.py do not.

Both scripts run entirely on your machine. Nothing is uploaded, and nothing
leaves your computer. The scripts only read this folder and write one zip
into it.

Full instructions, including what to do when it stops:
the Submit step at the end of the Week 7 lab on the course site.
