# Week 7 Lab Submission — How a Machine Learns, and How It Is Wired

AI Principles and Practice · COMP-0987 · Topic 07, Unit 02

One section below for each section of the lab. Answer as you go, rather than
at the end — most of these are the questions in the lab text.

Short answers. One or two sentences unless it says otherwise. Delete each
`TODO` as you finish that section, then run `python make_submission.py`.

| | |
|---|---|
| Student number | TODO |
| Name | TODO |
| Date | TODO |

---

## Setup

**0.1 Paste the two lines your setup script printed.**

TODO

---

## Section 1 — A model is a formula with dials

**1.1 Paste the three lines `section1_dials.py` printed.**

TODO

**1.2 Show by hand how the misses −60, −90 and −120 give a loss of 8700.**

TODO

**1.3 With `b = 40`, is `a = 2000` still perfect? Give the loss, and say why
changing one dial changes the best value of the other.**

TODO

**1.4 Exercise 1.2: sort `a`, `b`, the step size, the number of hidden layers,
the weights of a neuron and the number of epochs into parameters and
hyperparameters.**

TODO

---

## Section 2 — Guess, with one neuron

**2.1 Paste the two lines `section2_neuron.py` printed.**

TODO

**2.2 With the umbrella's caution at −3.0: the score, "how sure", and the decision.**

TODO

**2.3 Which loan clue argues against default, and how can you tell from the numbers?**

TODO

**2.4 Paste the line `section2_line.py` printed. Where are the mistakes, and why
can no setting of the weights fix them?**

TODO

---

## Section 3 — Guess, with a network: how it is wired

**3.1 Paste the four lines `section3_xor.py` printed.**

TODO

**3.2 With the bend removed: which dot gets the wrong answer, what is its hidden
pair, and why does every neuron need a bend?**

TODO

**3.3 Paste the three lines `section3_network.py` printed, and explain the 337
(weights and biases per layer).**

TODO

**3.4 Why do the hidden layers use ReLU and the last layer the sigmoid?**

TODO

---

## Section 4 — Check and nudge

**4.1 Paste the three lines `section4_losses.py` printed. What loss do you expect
from a network that guesses 0.5 for everything?**

TODO

**4.2 Paste the six lines `section4_walk.py` printed. Why does a negative slope
make the dial go up?**

TODO

**4.3 Paste the five lines `section4_steps.py` printed. One word for each step
size (crawling, settled, bouncing, exploding), and where the switch happens.**

TODO

---

## Section 5 — Blame

**5.1 Paste the two lines `section5_nudge.py` printed. With the truth at 9: the
blame, and which way `w` should turn.**

TODO

**5.2 Paste the line `section5_gradcheck.py` printed with your working `backward`.**

TODO

**5.3 With `* (self.z[i - 1] > 0)` deleted: the relative difference you got, and
what it tells you about gradient checks.**

TODO

---

## Section 6 — The loop, running

**6.1 Paste the five lines `section6_moons.py` printed.**

TODO

**6.2 Why is the untrained network worse than a coin toss, and why is its loss
close to your prediction in 4.1?**

TODO

**6.3 What would you have concluded if you had stopped at epoch 50?**

TODO

**6.4 Paste the lines `section6_credit.py` printed.**

TODO

**6.5 Why does a curved boundary help so much on the moons and so little on the
credit data? (Two or three sentences.)**

TODO

**6.6 Recall is 0.318. What would you change to catch more defaulters, and what
would it cost?**

TODO

---

## Section 7 — Exercises

**7.1 Your three step sizes: test loss and accuracy for each, and your sentence on
judging a run by accuracy alone.**

TODO

**7.2 Your fix log for `broken_run.py`, one line per run:
what I changed | test loss | test accuracy | what it told me.**

TODO

**7.3 Practice and new-dots accuracy with and without weight decay. Which run
memorised, and how big was each gap?**

TODO

**7.4 Recall and precision at thresholds 0.5, 0.3 and 0.2, against your Week 2
results, and your two sentences.**

TODO

**7.5 (optional) The largest gradient difference between your NumPy network and
PyTorch, and the five-line loop with each line's loop step named.**

TODO — or write "not attempted"
