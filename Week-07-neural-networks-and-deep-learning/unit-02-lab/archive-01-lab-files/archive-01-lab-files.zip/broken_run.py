# broken_run.py — this training run is broken on purpose. Do not rewrite it from scratch:
# find each problem, fix ONE thing at a time, re-run, and log what changed (Exercise 7.2).
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from mlp import MLP, bce

df = pd.read_csv("UCI_Credit_Card.csv")
y = df["default.payment.next.month"].to_numpy().reshape(-1, 1).astype(float)
X = df.drop(columns=["ID", "default.payment.next.month"]).to_numpy(float)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=0, stratify=y)

net = MLP([Xtr.shape[1], 16, 16, 1])
rng = np.random.default_rng(0)
lr, batch = 5.0, 64
for epoch in range(1, 11):
    order = rng.permutation(len(Xtr))
    for s in range(0, len(Xtr), batch):
        b = order[s:s + batch]
        net.forward(Xtr[b])
        gW, gb = net.backward(ytr[b])
        for P, g in zip(net.W + net.b, gW + gb):
            P += lr * g
    p = net.forward(Xte)
    print(f"epoch {epoch:2d}   test loss {bce(p, yte):.3f}   test accuracy {((p > 0.5) == yte).mean():.3f}")
