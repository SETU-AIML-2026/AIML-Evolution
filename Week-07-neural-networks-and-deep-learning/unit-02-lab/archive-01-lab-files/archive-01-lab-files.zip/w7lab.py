"""w7lab.py — provided helpers for the Week 7 lab. You do not need to edit this file.

    from w7lab import load_moons, load_credit, house_data, plot_boundary
"""
import numpy as np
import pandas as pd
from sklearn.datasets import make_moons
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def house_data():
    """The three houses from the lecture: sizes in m², prices in thousands of euro."""
    return np.array([60.0, 90.0, 120.0]), np.array([180.0, 240.0, 300.0])


def load_moons():
    """The two-moons dots from the lecture: 420 to learn from, 180 kept back."""
    X, y = make_moons(600, noise=0.2, random_state=0)
    y = y.reshape(-1, 1).astype(float)
    p = np.random.default_rng(0).permutation(600)
    return X[p[:420]], y[p[:420]], X[p[420:]], y[p[420:]]


def load_credit(path="UCI_Credit_Card.csv"):
    """The UCI credit data, split exactly as in the Week 2 lab, and scaled.

    Returns Xtr, ytr, Xte, yte as NumPy arrays (y as a column of 0s and 1s)
    and the list of feature names. The scaler is fitted on the training part only.
    """
    df = pd.read_csv(path)
    y = df["default.payment.next.month"].to_numpy().reshape(-1, 1).astype(float)
    X = df.drop(columns=["ID", "default.payment.next.month"])
    names = list(X.columns)
    Xtr, Xte, ytr, yte = train_test_split(X.to_numpy(float), y, test_size=0.25,
                                          random_state=0, stratify=y)
    scaler = StandardScaler().fit(Xtr)
    return scaler.transform(Xtr), ytr, scaler.transform(Xte), yte, names


def plot_boundary(predict, X, y, title="", fname=None):
    """Shade where predict(points) > 0.5 and draw the dots. predict takes an (n, 2) array."""
    import matplotlib.pyplot as plt
    gx, gy = np.meshgrid(np.linspace(-1.6, 2.6, 300), np.linspace(-1.15, 1.6, 220))
    grid = np.c_[gx.ravel(), gy.ravel()]
    P = np.asarray(predict(grid)).reshape(gx.shape)
    plt.figure(figsize=(6, 4))
    plt.contourf(gx, gy, P, levels=np.linspace(0, 1, 21), cmap="RdBu_r", alpha=0.35)
    plt.contour(gx, gy, P, levels=[0.5], colors="k")
    plt.scatter(X[:, 0], X[:, 1], c=y.ravel(), cmap="coolwarm", s=12, edgecolors="none")
    plt.title(title)
    plt.tight_layout()
    if fname:
        plt.savefig(fname, dpi=120)
    plt.show()
