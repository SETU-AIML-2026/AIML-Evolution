Week 7 lab files — AI Principles and Practice
=============================================

Unzip into a new folder called week07-lab and work there.

  UCI_Credit_Card.csv   The UCI "Default of Credit Card Clients" data: the same
                        file as Weeks 1 to 5. Used in Section 6 and Section 7.
  w7lab.py              Small helpers so you can spend your time on the network:
                        house_data(), load_moons(), load_credit() and
                        plot_boundary(). You do not need to edit it.
  broken_run.py         A training run that is broken on purpose, for
                        Exercise 7.2. Fix it one change at a time.

You write everything else yourself, starting with mlp.py in Section 2.
Then download the Week 07 Submission Kit into the same folder.

Dataset: Yeh, I. and Lien, C. (2009), UCI Machine Learning Repository,
https://doi.org/10.24432/C55S3H, licensed CC BY 4.0.
