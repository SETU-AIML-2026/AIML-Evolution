# Datasheet — <dataset name>

*Template after Gebru et al., "Datasheets for Datasets". Booklet Chapter 15.
Written by whoever collected the data, while they still remember.*

## Motivation
- Why was this dataset created, and for what task?
- Who created and funded it?

## Composition
- What does each instance represent?
- How many instances, and is it a sample of a larger set? If sampled, how?
- What data does each instance consist of?
- Is there a label, and **what does the label actually record** (as opposed to
  what it is called)?
- Are there identifiable groups (sex, ethnicity, age, disability)? Counts?
- Is any information missing, and is it missing unevenly across groups?

## Collection
- How was the data acquired, over what period, by whom?
- Were people told, and did they consent? Could they withdraw?
- Was an ethics review carried out?

## Preprocessing
- What cleaning, filtering or labelling was done? Is the raw data retained?

## Uses
- What tasks has it been used for?
- **What tasks should it NOT be used for?**
- What must a user know to avoid causing harm with it?

## Distribution and maintenance
- Who can access it, under what licence?
- Who maintains it, and how are errors reported and corrected?
- Retention and deletion schedule, especially for any special-category data
  held for bias testing (booklet Chapter 14).
