# Week 2 Submission

**Student number:** 20000000
**Name:** A. Student

> This sheet is **already filled in** with the answers from the reference run
> (`data/lending_data.csv`, seed 1). Your job is to run each notebook cell and
> **check every number against your own screen**. If a number differs, change it
> to yours. Add your student number and name, then run `python make_submission.py`.

---

## 0. Environment check

Output of `python setup_check.py` on the reference machine:

```
14 ready · 4 to sort out later · 0 blocking
Nothing blocking.  (shap, lime, ipywidgets and a compiler are the four "later" items; none is used.)
```

---

## Step 1 · Meet the data

**1a.** Share of the dataset that is group B: **0.204** (1,628 of 8,000 people, about one fifth)

**1b.** Recorded repayment rate: group A **0.547**, group B **0.437**

**1c.** The groups are equally able to repay (true ability −0.017 vs −0.005), so the difference in 1b is caused by **how the data was made**, not ability.

**1d.** "Some group B people who repaid were recorded as defaulting" belongs to pipeline stage **Labels** (the recorded outcome is a record of what the institution wrote down, not what happened).

---

## Step 2 · Does hiding `group` fix it?

**2a.** Accuracy of guessing `group` from the permitted columns: **99.6 %** (a lazy "always A" guess scores 79.6 %)

**2b.** The column that leaks the group: **`postcode_score`** (importance 0.326; every other column is below 0.001)

**2c.** Deleting the `group` column does not stop the model treating the groups differently because `postcode_score` carries almost the same information: the model can still tell the groups apart through the proxy, so the group was never really hidden.

---

## Step 3 · The model, and the line you draw

**3a.** At threshold 0.5 — approval rate A **0.596**, B **0.393**, gap **0.203**

**3b.** Another threshold tried: threshold **0.40** → gap **0.19** → overall approval rate **about 70 %**. (At 0.30 the gap is about 0.15 with about 85 % approved; lowering the line approves more people but the gap barely closes.)

**3c.** At the threshold with the smallest gap (0.98), the share of people who get a loan: **1.9 %** (gap 0.024, accuracy 0.489)

**3d.** A fairness number must be reported together with the approval rate because the gap can be made almost zero by approving nearly nobody (0.98) or nearly everybody (0.02); without the approval rate you cannot tell a fair lender from a useless one.

---

## Step 4 · Four fixes, and what each costs

**4a.** The fix that made the approval gap *worse*: **drop `postcode_score`** (gap 0.203 → 0.273, because the model leaned harder on the other columns that also leak the group)

**4b.** The fix that got the gap to 0.000: **per-group thresholds tuned for the selection gap** (A 0.48, B 0.30) — and the other gap that went up: **`ppv_gap`, 0.079 → 0.163** (an approved B applicant is now less likely to actually repay than an approved A applicant)

**4c.** The fix that worked best overall: **fix the label (stage 3)** — accuracy went from 0.699 to **0.698** (no real cost) while the approval gap fell to **0.033** and every other gap fell too (tpr 0.033, fpr 0.032, ppv 0.009)

**4d.** Fixing the *label* worked better than fixing the *model* because the harm was introduced at the Labels stage of the pipeline; correcting the labels removes it at source, whereas model-side fixes can only move errors from one group to another.

---

## Step 5 · The mini model card

`model_card.md` exists and all six boxes are filled: **yes** (see `model_card.md` in this folder; `datasheet.md` for the dataset is also completed)

---

## Optional

Tried: *Going further* A (mechanism table): `historical_bias` alone gives a gap of 0.148, `label_bias` alone costs the most accuracy (0.662), `proxy` alone does nothing (0.004) until another mechanism gives it something to leak. B (impossibility table): each row zeroes one gap and no row zeroes all three. D: logistic regression is slightly *more* accurate on the worst group (B 0.684 vs 0.668) than the gradient-boosted model.

**Roughly how long did the lab take?** about 2 hours

**Anything that did not work?** Nothing on the reference run. (The earlier edition's plots did not show in Jupyter; fixed.)
