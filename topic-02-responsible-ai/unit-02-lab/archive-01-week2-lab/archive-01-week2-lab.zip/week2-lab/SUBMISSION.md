# Week 2 Submission

**Student number:**
**Name:**

> Answer the questions below, then run `python make_submission.py` in this
> folder. That produces the single file you upload.
>
> Delete each `TODO` as you finish that section. The script will not build
> your submission while any remain — that is deliberate, so you never upload
> a half-finished file by accident.
>
> This week also has a **model card**. Copy `model_card_template.md` to
> `model_card.md` and fill it in; the script looks for that file by name.

---

## 1. Environment check

Run `python setup_check.py` and paste the whole output below.

Aim for **0 blocking**. `shap`, `lime` and `ipywidgets` are allowed to be
missing: `explain.py` carries its own LIME and the lab runs without them.

```
TODO paste the setup_check.py output here
```

---

## 2. Exercise 1 — Isolate the mechanisms

`make_lending_data()` takes four switches: `sampling_bias`, `historical_bias`,
`proxy` and `label_bias`. Regenerate with **one at a time** and record which
metric responds.

**Which mechanism produces the largest selection-rate gap? Which produces the
largest calibration error? Are they the same mechanism?**

Paste your table of results, then two or three sentences interpreting it.

TODO

---

## 3. Exercise 2 — Find the degenerate solution

Find a threshold at which the demographic-parity gap is essentially zero.

**Report the selection rate as well, and explain why a fairness number quoted
without the selection rate is unreported rather than good.**

Two or three sentences. Name the group that this "fair" threshold serves worst.

TODO

---

## 4. Exercise 3 — Break the explanation

Take one refused group-B applicant. Explain the decision with all three
methods (`lime_from_scratch`, `lime_library`, `shap_values`) and compute the
rank correlation between the orderings.

**Which explanation would you put in front of the refused applicant, and why?
What would you say if they asked whether the other two agreed?**

Save your comparison plot as `submission-explanations.png` **in this folder**.
Do not put it in `figures/` — that folder is in `.gitignore` and is emptied
when `run_lab.py` regenerates, so anything saved there will be lost.

TODO

---

## 5. Exercise 4 — The Week 9 preview

Retrain with `model="logreg"` and compare **worst-group accuracy** against the
gradient-boosted model.

**Which model is fairer, which is more accurate on aggregate, and would
anyone reading only the headline number have been told?**

Three sentences. This is the Week 9 compression argument in miniature.

TODO

---

## 6. Exercise 5 — The model card

Copy `model_card_template.md` to `model_card.md` and complete it for the model
you trained.

The graded parts are: **the fairness criterion you committed to**, **the
reasoning behind that choice**, and **what you gave up to get it**. State the
cost in numbers from your own run, not in general terms.

Confirm below that `model_card.md` exists and is finished.

TODO

---

## 7. The seven questions, applied

Pick **one** deployed system you personally used this week. Run it through
**four** of the seven questions in Chapter 16 of the booklet, in under two
hundred words.

By Week 12 this is a draft section of your project's critical brief.

TODO

---

## 8. Anything that did not work

Optional, and genuinely useful. If something took far longer than it should
have, or an instruction was wrong, say so. This is how the lab improves.
