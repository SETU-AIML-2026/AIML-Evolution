# Week 2 Lab — Responsible AI: auditing a dataset and a model

**The Evolution of Machine Learning and AI** · SETU · Award Certificate in AI and ML Engineering

Two hours. You will audit a dataset, train a competent model, discover that it
discriminates, try four fixes, and find out which one actually works.

## Setup

```bash
bash setup.sh              # macOS / Linux   (Windows: .\setup.ps1)
```

That creates the virtual environment, installs the core packages, attempts the
optional ones, runs the environment check and then runs the lab once as a smoke
test. By hand instead:

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements-core.txt
pip install -r requirements.txt   # adds shap, lime, ipywidgets — allowed to fail
python setup_check.py      # never crashes; tells you what is missing
python run_lab.py          # end-to-end smoke test, ~40 seconds
```

In Colab, run the first cell of `week2_lab.ipynb`; everything else is pure
Python and needs no local install.

`shap`, `lime` and `ipywidgets` are optional. `explain.py` contains a
from-scratch LIME in thirty lines, so the lab never blocks on a failed install.

## The files

| file | what it is |
|---|---|
| `datasets.py` | The lending dataset, with four bias mechanisms you can switch on and off individually. **Start here.** |
| `fairness.py` | Every fairness metric, written out in numpy. No library. |
| `explorer.py` | The Bias & Fairness Explorer: distributions, threshold sweep, calibration, and the impossibility demonstration. |
| `explain.py` | SHAP, library LIME, and a from-scratch LIME; local and global views; the disagreement problem. |
| `mitigate.py` | Four mitigations compared on one table, with the cost of each. |
| `run_lab.py` | The whole thing end to end. |
| `week2_lab.ipynb` | The guided version, with the exercises. |
| `model_card_template.md`, `datasheet_template.md` | Your deliverables. Copy to `model_card.md` / `datasheet.md`. |
| `setup_check.py` | Environment report card. Aim for 0 blocking. |
| `make_submission.py` | Builds the single file you upload. |

## The dataset's one rule

**Both groups have identical latent creditworthiness.** There is no difference
in ability to repay. Every disparity you measure was manufactured by one of
four mechanisms, each corresponding to a stage of the booklet's pipeline:

| mechanism | pipeline stage | booklet |
|---|---|---|
| `sampling_bias` | 2. Data | Ch. 4, representation bias |
| `historical_bias` | 1. World | Ch. 4, historical bias |
| `proxy` | 2. Data | Ch. 5, proxy variables |
| `label_bias` | 3. Labels | Ch. 5, label bias |

If you ever catch yourself explaining a gap by saying "group B is just riskier",
open the generator. You wrote it. They aren't.

## What you should find

Running `run_lab.py` on the default seed:

- `group` is recoverable from the "permitted" features with **~99.6% accuracy**.
  Fairness through unawareness fails before you train anything.
- At `t = 0.5` the selection-rate gap is about **20 points**.
- **Dropping the obvious proxy makes the gap worse**, not better: the model
  leans harder on the proxies that remain.
- Per-group thresholds zero whichever gap you tune for, and inflate the others.
  That is the impossibility result of Chapter 9, reproduced on your laptop.
- **Fixing the label removes nearly all of the disparity at almost no accuracy
  cost**, because that is where the harm was introduced.

## Exercises

1. **Isolate the mechanisms.** Regenerate with one mechanism at a time and
   record which metric responds. Which mechanism produces the largest selection
   gap? Which produces the largest calibration error?
2. **Find the degenerate solution.** Find a threshold with a perfect
   demographic-parity gap. Report the selection rate too, and explain why any
   fairness result quoted without it is unreported.
3. **Break the explanation.** Explain the same applicant with all three
   methods. Compute the rank correlation. Decide which you would put in front
   of a refused applicant, and defend it.
4. **The Week 9 preview.** Retrain with `model="logreg"` and compare worst-group
   accuracy against the GBM. Which model is fairer, and did anyone tell you that
   when they reported the aggregate score?
5. **Write the model card.** Use the template. The fairness criterion and the
   reasoning behind it are the graded part.

## Submitting

```bash
cp model_card_template.md model_card.md    # this week's graded deliverable
python make_submission.py                  # builds submission-week02-<you>.zip
```

Upload that one zip. The script stops if `SUBMISSION.md` still has `TODO`
markers or if `model_card.md` does not exist; `--force` overrides both.

## Assessment link

LO6 is examined in the Week 6 quiz and again in the responsibility section of
the Week 12 project. The model card you write here is the format that section
takes.
