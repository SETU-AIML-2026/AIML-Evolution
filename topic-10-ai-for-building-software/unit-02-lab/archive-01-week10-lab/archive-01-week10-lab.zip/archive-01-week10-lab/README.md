# Week 10 Lab File

`capstone_step4.ipynb`: open it in Google Colab (Upload, Browse), then File, Save a copy in Drive.

Run Step 0, Part A and the class example's three tests. Then, in the same part as before (2, 3 or 4), paste your whole Week 8 YOUR TURN cell, write the three new lines, and run your tests.

The walkthrough video and the core booklet (Chapters 4 to 7) show every step.
