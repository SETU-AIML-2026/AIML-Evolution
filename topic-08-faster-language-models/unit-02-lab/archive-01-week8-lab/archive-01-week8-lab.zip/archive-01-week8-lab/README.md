# Week 8 Lab File

`capstone_step2.ipynb`: open it in Google Colab (colab.research.google.com → Upload → Browse), then File → Save a copy in Drive.

Run Step 0, Part A (the speed visualiser) and Part 1 (the class example). Then use the same part as in Week 7 (2, 3 or 4) for your own law: copy in your Week 7 lines, set your success test, and train your first model.

The walkthrough video and the core booklet (Chapters 4 to 7) show every step.
